
// document.getElementById("submit").addEventListener("click", bmiCalculator);
function bmiCalculator(){
var height = parseInt(document.getElementById("height").value);
var weight = parseFloat(document.getElementById("weight").value);
var bmi;
var newheight= parseFloat(height/100);
bmi = weight / (newheight * newheight);
bmi = bmi.toFixed(1);
var color,msg;
document.getElementById("result").innerHTML = bmi;
if(bmi < 18.5){
    msg = "That you are too thin."
    color = "red";
    }
    if(bmi > 18.5 && bmi < 25){
       msg = "That you are healthy."
        color = "green";
    }
    if(bmi > 25){
         msg= "That you have overweight."
        color= "red";
    }
    document.getElementById("report").innerHTML=msg;
    document.getElementById("report").style.color =color;
    document.getElementById("result").style.color =color;

}

